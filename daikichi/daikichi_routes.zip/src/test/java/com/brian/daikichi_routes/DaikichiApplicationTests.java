package com.brian.daikichi_routes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DaikichiApplicationTests {

	@Test
	void contextLoads() {
	}

}
